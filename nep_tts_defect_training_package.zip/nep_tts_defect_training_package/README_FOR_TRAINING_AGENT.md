# Nepali TTS Training Pipeline - Defect Retraining Package

## Overview
This package contains 221 human-evaluated speech synthesis defects identified by Subash Sah across 1,712 Nepali polysemous sentences.
No audio binaries are included in this archive; instead, **absolute local filesystem paths** are embedded so the training agent on this system can directly ingest the waveforms without data duplication.

---

## Files in Package
```
nep_tts_defect_training_package/
├── README_FOR_TRAINING_AGENT.md         <- Training agent guidelines & taxonomy
├── subash_annotation_defect_report.md   <- Comprehensive defect catalog & linguistics
└── manifests/
    ├── defects_train_manifest.jsonl     <- Line-by-line JSONL with absolute audio paths
    ├── training_pipeline_defects.json   <- Complete JSON dataset with categories & recurrence weights
    └── annotation_defects.csv           <- Tabular CSV with metadata and audio paths
```

---

## Audio Locations on This Device
- **Candidate Flawed Audios (OmniVoice)**:
  `/home/oem/wiseyak_backup/firojpaudel/nep_syn_plat/audios/{item_id}.wav`
- **Gold Standard Reference Audios (Gemini 3.8 Flash)**:
  `/home/oem/wiseyak_backup/firojpaudel/nep_syn_plat/static/reference_audio/{item_id}.wav`
  (Also linked at `/home/oem/wiseyak_backup/wiseai-training-pipeline/data/gemini_polysemous/audios/`)

---

## Top Defect Categories & Prescriptions for the Agent

| Category | Count | Priority | Root Cause & Training Prescription |
|---|---|---|---|
| `negative_prefix_prosody_stress` | 8 | High | **Unnatural stress on negative prefix `न-`** (`नदिन` 7x, `नडराई`, `नपाएको`). Shift duration & primary stress to root verb. |
| `consonant_cluster_coarticulation` | 43 | High | **Devanagari conjunct blurring** (`प्रस्ट` 5x, `मञ्चको`, `ढकमक्क`, `दृष्टि`). Fine-tune stop-fricative transitions in acoustic model. |
| `case_marker_boundary_prosody` | 37 | Medium | **Boundary elongation on case markers** (`-मा`, `-को`, `-का`, `-की`, `-लाई`, `-ले`). Group vibhakti with stem in front-end prosodic parsing. |
| `nasalization_chandrabindu_loss` | 26 | High | **Loss of Chandrabindu `ँ` nasal formant** (`साँझपख` 3x, `भौँतारिन`, `आँक`). Align 2.5-3.5 kHz spectral loss with gold reference audio. |
| `lexical_pronunciation_defect` | 95 | Medium | **Polysemic lexical pronunciation drift** (`तर` 5x, `खान` 3x, `खेर` 3x, `पटेर` 3x). Add G2P phonetic override dictionary entries. |

---

## Quick Load Example (Python)
```python
import json
from pathlib import Path

manifest_path = "manifests/defects_train_manifest.jsonl"
with open(manifest_path, "r", encoding="utf-8") as f:
    samples = [json.loads(line) for line in f]

for s in samples:
    text = s["text"]
    cand_wav = Path(s["candidate_audio"])   # Flawed candidate wav
    ref_wav = Path(s["reference_audio"])    # Gold benchmark wav
    weight = s["recurrence_weight"]         # Loss multiplier (e.g. 7x for 'नदिन')
    # Train / fine-tune model here
```
